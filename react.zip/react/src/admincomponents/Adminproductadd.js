import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Left from "./Left";

function Adminproductadd() {
    const navigate=useNavigate()
    const[name,setName]=useState('')
    const[desc,setDesc]=useState('')
    const[price,setPrice]=useState('')
    const[message,setMessage]=useState('')

function hanldeform(e){
    e.preventDefault()
    const formdata={name,desc,price}
    fetch('/api/productadd',{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(formdata)
    }).then((res)=>{ return res.json()}).then((data)=>{
        //console.log(data)
        if(data._id){
            navigate('/adminproducts')
        }else{
            setMessage('Error Occured')
        }
    })
}
    return ( 
        <section id="mid">
            <div className="container">
            <div className="row">
                <Left/>
            <div className="col-md-9">
                <h2>Product Add Here</h2>
                <form onSubmit={(e)=>{hanldeform(e)}}>
                    <label>Product Name</label>
                    <input type=""
                    value={name}
                    onChange={(e)=>{setName(e.target.value)}}
                    className="form-control" />
                    <label>Product Description</label>
                    <input type=""
                    value={desc}
                    onChange={(e)=>{setDesc(e.target.value)}}
                    className="form-control" />
                    <label>Product Price</label>
                    <input type=""
                    value={price}
                    onChange={(e)=>{setPrice(e.target.value)}}
                    className="form-control" />
                    <button className="form-control btn btn-success mt-2 mb-2">Add Product</button>
                </form>
            </div>

            </div>

            </div>
        </section>
     );
}

export default Adminproductadd;