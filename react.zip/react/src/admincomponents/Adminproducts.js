import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Left from "./Left";

function Adminproducts() {
    const[products,setProducts]=useState([])
    const [message,setMessage]=useState('')
    const[isloading,setIsloading]=useState(true)
useEffect(()=>{
    fetch('/api/adminallproducts').then((res)=>{return res.json()}).then((data)=>{
        //console.log(data)
        setProducts(data)
        setIsloading(false)
    })
   
},[products])

function hanldedelete(e,id){
    fetch(`/api/productdelete/${id}`,{
        method:'DELETE'
    }).then((res)=>{return res.json()}).then((data)=>{
        if(data.message==='Successfully Deleted')
        {
            setMessage(data.message)
        }
        
    })
}
    return ( 
        <section id="mid">
 
            <div className="container">
            <div className="row">
                <Left/>
            <div className="col-md-9">
                <h2>Products Management</h2>
                {message}
                <Link to="/adminproductadd"><button className="btn btn-success form-control">Add Product Here</button></Link>
                    {isloading && <h2>Data is loading.....</h2>}
                <table className="table table-hover">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Product Description</th>
                            <th>Product Price</th>
                            <th>Product Status</th>
                            <th>Update</th>
                            <th>Delete</th>
                            <th>Delete 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                        products.map((result)=>(
                            <tr key={result._id}>
                            <td>{result.name}</td>
                            <td>{result.desc}</td>
                            <td>{result.price}</td>
                            <td>{result.status}</td>
                            <td><Link to={`/adminproductupdate/${result._id}`}><button>Update</button></Link></td>
                            <td><Link to={`/productdelete/${result._id}`}><button>Delete</button></Link></td>
                            <td><button onClick={(e)=>{hanldedelete(e,result._id)}}>Delete</button></td>
                        </tr>
                        ))}
                        
                    </tbody>
                </table>
            </div>

            </div>

            </div>
        </section>
     );
}

export default Adminproducts;