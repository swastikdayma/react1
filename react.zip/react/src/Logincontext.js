import { createContext } from 'react'





export const Logincontext=createContext(null)