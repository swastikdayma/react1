function Footer() {
    return ( 
        <section id="footer">
        <div className="container">
        <div className="row">
            <div className="col-md-12">
                <h2>@Footer</h2>
            </div>
        </div>
        </div>
        </section>
     );
}

export default Footer;