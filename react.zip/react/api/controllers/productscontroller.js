const Products=require("../models/products")




exports.adminproductadd=async(req,res)=>{
    const{name,desc,price}=req.body
      const record= new Products({name:name,desc:desc,price:price,})
     await record.save()
     res.json(record)
}

exports.adminallproducts=async(req,res)=>{
   const record= await Products.find()
   res.json(record)
}

exports.adminsingleproduct=async(req,res)=>{
   const id=req.params.id
   const record=await Products.findById(id)
   res.json(record)
}

exports.adminproductupdate=async(req,res)=>{
   const id=req.params.id
   const{name,price,desc,status}=req.body
   await Products.findByIdAndUpdate(id,{name:name,desc:desc,price:price,status:status})
   res.json({message:"Successfully Updated"})
}

exports.productdelete=async(req,res)=>{
   console.log(req.params.id)
   const id=req.params.id
   await Products.findByIdAndDelete(id)
   res.json({message:"Successfully Deleted"})
}

exports.productinall=async(req,res)=>{
  const record= await Products.find({status:'IN-STOCK'})
  res.json(record)
}

exports.cartproducts=async(req,res)=>{
   const{ids}=req.body
  const record= await Products.find({_id:{$in:ids}})
  res.json(record)

}


